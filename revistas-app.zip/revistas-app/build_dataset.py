"""
Construye data/revistas_procesadas.csv.gz a partir de:
  - Scopus Source List (xlsx, hoja 1 "Scopus Sources ...")
  - SCImago Journal Rank (csv separado por ';')

Uso:
    python build_dataset.py RUTA_SCOPUS.xlsx RUTA_SCIMAGO.csv
"""
import sys
import re
import pandas as pd

OUT = "data/revistas_procesadas.csv.gz"


def fmt_issn(x):
    """'15424863' -> '1542-4863' (None si no es válido)."""
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return None
    x = re.sub(r"[^0-9Xx]", "", str(x)).upper()
    if len(x) != 8:
        return None
    return f"{x[:4]}-{x[4:]}"


def to_num(s):
    return pd.to_numeric(s.astype(str).str.replace(",", ".", regex=False), errors="coerce")


def build(scopus_xlsx, scimago_csv, out=OUT):
    sc = pd.read_excel(scopus_xlsx, sheet_name=0, dtype=str)
    sc.columns = [re.sub(r"\s+", " ", c).strip() for c in sc.columns]
    sc = sc.rename(columns={"Sourcerecord ID": "sourceid", "Source Title": "titulo",
                            "ISSN": "issn_scopus", "EISSN": "eissn_scopus",
                            "Active or Inactive": "estado_scopus", "Coverage": "cobertura_scopus",
                            "Source Type": "tipo", "Publisher": "editorial_scopus",
                            "Open Access Status": "oa_scopus",
                            "Article Language in Source (Three-Letter ISO Language Codes)": "idiomas"})
    areas_cols = [c for c in sc.columns if re.match(r"^\d{4} ", c)]
    sc["areas_scopus"] = sc[areas_cols].apply(
        lambda r: "; ".join(v.strip() for v in r.dropna().astype(str) if v.strip()), axis=1)
    sc = sc[["sourceid", "titulo", "issn_scopus", "eissn_scopus", "estado_scopus", "cobertura_scopus",
             "tipo", "editorial_scopus", "oa_scopus", "idiomas", "areas_scopus"]]

    sj = pd.read_csv(scimago_csv, sep=";", dtype=str)
    sj = sj.rename(columns={"Sourceid": "sourceid", "Issn": "issn_sjr", "SJR": "sjr",
                            "SJR Best Quartile": "cuartil", "H index": "h_index",
                            "Open Access": "open_access", "Open Access Diamond": "diamond",
                            "Country": "pais", "Categories": "categorias", "Areas": "areas",
                            "Publisher": "editorial_sjr", "Total Docs. (2025)": "docs_2025",
                            "Citations / Doc. (2years)": "citas_por_doc_2a", "Rank": "rank_sjr"})
    sj["sjr"] = to_num(sj["sjr"])
    sj["citas_por_doc_2a"] = to_num(sj["citas_por_doc_2a"])
    sj["h_index"] = to_num(sj["h_index"])
    sj["docs_2025"] = to_num(sj["docs_2025"])
    sj = sj[["sourceid", "issn_sjr", "sjr", "cuartil", "h_index", "open_access", "diamond", "pais",
             "categorias", "areas", "editorial_sjr", "docs_2025", "citas_por_doc_2a", "rank_sjr"]]

    df = sc.merge(sj, on="sourceid", how="outer", indicator=True)
    df["en_scopus"] = df["_merge"].isin(["both", "left_only"])
    df["en_scimago"] = df["_merge"].isin(["both", "right_only"])
    df = df.drop(columns="_merge")
    # Títulos de SCImago que no estén en la lista de Scopus
    miss = df["titulo"].isna()
    if miss.any():
        t = pd.read_csv(scimago_csv, sep=";", dtype=str, usecols=["Sourceid", "Title", "Type"])
        t = t.set_index("Sourceid")
        df.loc[miss, "titulo"] = df.loc[miss, "sourceid"].map(t["Title"])
        df.loc[miss, "tipo"] = df.loc[miss, "sourceid"].map(t["Type"]).str.title()
    df["editorial"] = df["editorial_scopus"].fillna(df["editorial_sjr"])

    # ISSN / eISSN: Scopus distingue impreso y electrónico
    df["issn"] = df["issn_scopus"].map(fmt_issn)
    df["eissn"] = df["eissn_scopus"].map(fmt_issn)
    sjr_issns = df["issn_sjr"].fillna("").str.split(r",\s*")
    df["issn"] = df["issn"].fillna(sjr_issns.map(lambda l: fmt_issn(l[0]) if l and l[0] else None))
    df["eissn"] = df["eissn"].fillna(sjr_issns.map(lambda l: fmt_issn(l[1]) if len(l) > 1 else None))

    # Áreas: SCImago si existe, si no las de Scopus
    df["areas"] = df["areas"].fillna(df["areas_scopus"])
    df["activa"] = df["estado_scopus"].fillna("Active").eq("Active")

    # Tipo de acceso / costo (derivado SOLO de los flags de SCImago/Scopus; no hay datos de APC)
    def acceso(r):
        if r["diamond"] == "Yes":
            return "Diamond OA (gratis para autor y lector)"
        if r["open_access"] == "Yes":
            return "Open Access (suele cobrar APC)"
        if r["open_access"] == "No":
            return "Suscripción (publicar suele ser gratis; opción OA híbrida con pago)"
        if isinstance(r["oa_scopus"], str):
            return "Open Access (según Unpaywall; verificar APC)"
        return "Sin dato de acceso"
    df["acceso"] = df.apply(acceso, axis=1)
    df["publicar_costo"] = df["acceso"].map(lambda a: "GRATIS" if a.startswith("Diamond") else
                                            "PAGO (APC probable)" if a.startswith("Open Access") else
                                            "Normalmente GRATIS (suscripción)" if a.startswith("Suscrip") else
                                            "Verificar")
    df["cuartil"] = df["cuartil"].replace({"-": None})
    df["url_scimago"] = "https://www.scimagojr.com/journalsearch.php?q=" + df["sourceid"] + "&tip=sid"
    df["url_scopus"] = "https://www.scopus.com/sourceid/" + df["sourceid"]
    df["url_doaj"] = df["eissn"].fillna(df["issn"]).map(
        lambda i: f"https://doaj.org/toc/{i}" if isinstance(i, str) else None)

    cols = ["sourceid", "titulo", "tipo", "editorial", "pais", "issn", "eissn", "cuartil", "sjr", "h_index",
            "citas_por_doc_2a", "docs_2025", "open_access", "diamond", "acceso", "publicar_costo",
            "categorias", "areas", "idiomas", "cobertura_scopus", "activa", "en_scopus", "en_scimago",
            "url_scimago", "url_scopus", "url_doaj"]
    df = df[cols]
    df = df[df["tipo"].fillna("").str.lower().isin(["journal", "book series", "trade journal"])]
    df.to_csv(out, index=False, compression="gzip")
    return df


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    d = build(sys.argv[1], sys.argv[2])
    print(f"OK: {len(d):,} fuentes -> {OUT}")
